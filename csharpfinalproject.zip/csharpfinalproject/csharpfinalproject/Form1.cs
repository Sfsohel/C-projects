﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace csharpfinalproject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataClasses1DataContext dbs = new DataClasses1DataContext();
        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel5.Visible = true;

        }
        int txt7;
        int contract_id;

        private void Button7_Click(object sender, EventArgs e)
        {
            try
            {
                var q = from p in dbs.Admins
                        where
                      p.Id == Convert.ToInt32(textBox7.Text) &&
                      p.Password == textBox8.Text &&
                      p.ServiceName == (comboBox3.SelectedItem).ToString()
                        select p;
                if (q.Any())
                {
                    panel5.Visible = false;
                    panel7.Visible = true;

                    if (comboBox3.Text == "Bus_service")
                    {
                        //MessageBox.Show("Your service");
                        var data = from x in dbs.Bus_services
                                   where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                   select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Strat_Time, x.Admin_id, x.Depurture_time, x.Admin.Bus_services, x.Availability, x.Available_sit };
                        dataGridView3.DataSource = data;
                        txt7 = Convert.ToInt32(textBox7.Text);
                    }
                    if (comboBox3.Text == "Air")
                    {
                        var data = from x in dbs.Airs
                                   where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                   select new { x.Id, x.Name, x.Rent, x.Start_time, x.Departure_Time, x.Admin.ServiceName, x.Admin_id, x.Availability, x.Sit_Availability };

                        dataGridView3.DataSource = data;
                    }
                    if (comboBox3.Text == "Train_service")
                    {
                        var data = from x in dbs.Train_services
                                   where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                   select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Start_time, x.Departure_time, x.Admin.Bus_services, x.Admin_id, x.Availability, x.Sit_Availability };
                        dataGridView3.DataSource = data;
                    }
                }
                else
                {
                    MessageBox.Show("Not mached");
                }
                textBox21.Text = textBox7.Text;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}
        }

        private void paneluserselectbtn_Click(object sender, EventArgs e)
        {
            try
            {
                panel2.Visible = false;
                panel3.Visible = true;
                if (radioButton1.Checked)
                {

                    var data = from x in dbs.Bus_services
                               where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Start_place == (comboBox1.SelectedItem).ToString() && x.Departure_place == (comboBox2.SelectedItem).ToString()
                               select new {x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Available_sit, x.Strat_Time, x.Depurture_time };

                    dataGridView2.DataSource = data;

                    var data2 = from x in dbs.Accomodations
                                where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Location == (comboBox2.SelectedItem).ToString()
                                select new {x.Id, x.Name, x.Location, x.Rent, x.Room_Type, x.Service_Duration, x.Available_sit };

                    dataGridView1.DataSource = data2;

                }
                else if (radioButton2.Checked)
                {
                    var data = from x in dbs.Train_services
                               where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Start_place == (comboBox1.SelectedItem).ToString() && x.Departure_place == (comboBox2.SelectedItem).ToString()
                               select new {x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Sit_Availability, x.Start_time, x.Departure_time };

                    dataGridView2.DataSource = data;

                    var data2 = from x in dbs.Accomodations
                                where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Location == (comboBox2.SelectedItem).ToString()
                                select new {x.Id, x.Name, x.Location, x.Rent, x.Room_Type, x.Service_Duration, x.Available_sit }; ;

                    dataGridView1.DataSource = data2;
                }
                else if (radioButton3.Checked)
                {
                    var data = from x in dbs.Airs
                               where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Start_place == (comboBox1.SelectedItem).ToString() && x.Departure_place == (comboBox2.SelectedItem).ToString()
                               select new {x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Sit_Availability, x.Start_time, x.Departure_Time };

                    dataGridView2.DataSource = data;

                    var data2 = from x in dbs.Accomodations
                                where x.Rent <= Convert.ToInt32(textBox1.Text) && x.Location == (comboBox2.SelectedItem).ToString()
                                select new {x.Id, x.Name, x.Location, x.Rent, x.Room_Type, x.Service_Duration, x.Available_sit }; ;

                    dataGridView1.DataSource = data2;

                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Userinterbtn_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = true;

        }

        private void UserDenybtn_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel1.Visible = true;
        }

        private void Userproceedbtn_Click(object sender, EventArgs e)
        {
            try
            {
                panel3.Visible = false;
                panel4.Visible = true;

                if (dataGridView1.CurrentRow.Index != -1)
                {
                    contract_id = Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value.ToString());
                    textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    textBox3.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                    textBox4.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                    textBox5.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

                }
            }

            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void Usersingupbtn_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
            panel6.Visible = true;
        }

        private void Userloginbtn_Click(object sender, EventArgs e)
        {
            panel6.Visible =false;
            panel5.Visible = true;
        }

        private void Userprintbtn_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBox6.Text);
                var query = dbs.Bankdbs.Where(w => w.Id == id).FirstOrDefault();
                double amount = Convert.ToDouble(query.Amount);
                double busrent = Convert.ToDouble(textBox4.Text);
                double hotelrent = Convert.ToDouble(textBox5.Text);
                double totalamount = busrent + hotelrent;
                double subamount;
                if (amount < totalamount)
                    MessageBox.Show("sorry you haven't suficient balance!");
                else
                {
                    int id2 = int.Parse(textBox6.Text);
                    Bankdb s = dbs.Bankdbs.SingleOrDefault(x => x.Id == id2);
                    if (s != null)
                    {
                        subamount = amount - totalamount;
                        s.Amount = subamount;
                        dbs.SubmitChanges();
                    }
                    //OpenFileDialog ofd = new OpenFileDialog();
                    // ofd.ShowDialog();
                    Document doc = new Document();
                    PdfWriter.GetInstance(doc, new FileStream("E:/create.pdf", FileMode.Create));
                    doc.Open();
                    Paragraph p1 = new Paragraph("Hotel Name:" + textBox2.Text + "\n" + "Bus Name:" + textBox3.Text + "\n" + "Bus rent:" + textBox4.Text + "\n" + "Hotel rent:" + textBox5.Text);
                    doc.Add(p1);
                    doc.Close();
                    MessageBox.Show("your Ticket Saved at " + "E:");

                }
                if (radioButton1.Checked)
                {
                    var query2 = dbs.Bus_services.Where(w => w.Id == contract_id).FirstOrDefault();
                    int sit = Convert.ToInt32(query2.Available_sit);
                    if (sit > 0)
                    {
                        Bus_service s = dbs.Bus_services.SingleOrDefault(x => x.Id == contract_id);
                        if (s != null)
                        {
                            int updatesit = sit - 1;
                            s.Available_sit = updatesit.ToString();
                            dbs.SubmitChanges();
                        }
                    }
                    else
                    {
                        MessageBox.Show("sit is not Available");
                    }
                }
               else if (radioButton3.Checked)
                {
                    var query2 = dbs.Airs.Where(w => w.Id == contract_id).FirstOrDefault();
                    int sit = Convert.ToInt32(query2.Sit_Availability);
                    if (sit > 0)
                    {
                        Air s = dbs.Airs.SingleOrDefault(x => x.Id == contract_id);
                        if (s != null)
                        {
                            int updatesit = sit - 1;
                            s.Sit_Availability = updatesit;
                            dbs.SubmitChanges();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sit is not available");
                    }
                }
                else if (radioButton2.Checked)
                {
                    var query2 = dbs.Train_services.Where(w => w.Id == contract_id).FirstOrDefault();
                    int sit = Convert.ToInt32(query2.Sit_Availability);
                    if (sit > 0)
                    {
                        Train_service s = dbs.Train_services.SingleOrDefault(x => x.Id == contract_id);
                        if (s != null)
                        {
                            int updatesit = sit - 1;
                            s.Sit_Availability = updatesit;
                            dbs.SubmitChanges();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sit is not available");
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}

        }
        
        private void adminserviceinsert_Click(object sender, EventArgs e)
        {
            try
            {

                if (comboBox3.Text == "Bus_service")
                {
                    //  int pid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    //   var query = dbs.Bus_services.Where(w => w.Id == pid).FirstOrDefault();
                    Bus_service query = new Bus_service();
                    query.Name = textBox14.Text;
                    query.Strat_Time = Convert.ToString(comboBox4.SelectedItem);
                    query.Depurture_time = Convert.ToString(comboBox5.SelectedItem);
                    query.Type = textBox17.Text;
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Available_sit = textBox19.Text;
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.Bus_services.InsertOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Bus_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Strat_Time, x.Admin_id, x.Depurture_time, x.Admin.Bus_services, x.Availability, x.Available_sit };
                    MessageBox.Show("Insert sucessfully");
                }
                else if (comboBox3.Text == "Air")
                {
                    textBox21.Text = txt7.ToString();
                    //  int pid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    //   var query = dbs.Bus_services.Where(w => w.Id == pid).FirstOrDefault();
                    Air query = new Air();
                    query.Name = textBox14.Text;
                    query.Start_time = Convert.ToString(comboBox4.SelectedItem);
                    query.Departure_Time = Convert.ToString(comboBox5.SelectedItem);
                    query.Sit_Type = textBox17.Text;
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Sit_Availability = Convert.ToInt32(textBox19.Text);
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.Airs.InsertOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Airs
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_time, x.Departure_Time, x.Admin.ServiceName, x.Admin_id, x.Availability, x.Sit_Availability };

                    MessageBox.Show("Insert sucessfully");
                }
                else if (comboBox3.Text == "Train_service")
                {
                    //  int pid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    //   var query = dbs.Bus_services.Where(w => w.Id == pid).FirstOrDefault();
                    Train_service query = new Train_service();
                    query.Name = textBox14.Text;
                    query.Start_time = Convert.ToString(comboBox4.SelectedItem);
                    query.Departure_time = Convert.ToString(comboBox5.SelectedItem);
                    query.Sit_Availability = Convert.ToInt32(textBox17.Text);
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Sit_Availability = Convert.ToInt32(textBox19.Text);
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.Train_services.InsertOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Train_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_time, x.Departure_time, x.Admin.ServiceName, x.Admin_id, x.Availability, x.Sit_Availability };

                    MessageBox.Show("Insert sucessfully");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void adminupdatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox3.Text == "Bus_service")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Bus_services.Where(w => w.Id == pid).FirstOrDefault();
                    query.Name = textBox14.Text;
                    query.Strat_Time = Convert.ToString(comboBox4.SelectedItem);
                    query.Depurture_time = Convert.ToString(comboBox5.SelectedItem);
                    query.Type = textBox17.Text;
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Available_sit = textBox19.Text;
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Bus_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Strat_Time, x.Admin_id, x.Depurture_time, x.Admin.Bus_services, x.Availability, x.Available_sit };
                    MessageBox.Show("update sucessfully");
                }

                else if (comboBox3.Text == "Air")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Airs.Where(w => w.Id == pid).FirstOrDefault();
                    query.Name = textBox14.Text;
                    query.Start_time = Convert.ToString(comboBox4.SelectedItem);
                    query.Departure_Time = Convert.ToString(comboBox5.SelectedItem);
                    query.Sit_Type = textBox17.Text;
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Sit_Availability = Convert.ToInt32(textBox19.Text);
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Airs
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Start_time, x.Admin_id, x.Departure_Time, x.Admin.Bus_services, x.Availability, x.Sit_Availability };
                    MessageBox.Show("update sucessfully");
                }
                else if (comboBox3.Text == "Train_service")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Train_services.Where(w => w.Id == pid).FirstOrDefault();
                    query.Name = textBox14.Text;
                    query.Start_time = Convert.ToString(comboBox4.SelectedItem);
                    query.Departure_time = Convert.ToString(comboBox5.SelectedItem);
                    query.Type = textBox17.Text;
                    if (radioButton4.Checked)
                    {
                        query.Availability = "yes";
                    }
                    else if (radioButton5.Checked)
                    {
                        query.Availability = "no";
                    }

                    query.Sit_Availability = Convert.ToInt32(textBox19.Text);
                    query.Rent = Convert.ToInt32(textBox20.Text);
                    query.Admin_id = Convert.ToInt32(textBox21.Text);
                    query.Start_place = Convert.ToString(comboBox6.SelectedItem);
                    query.Departure_place = Convert.ToString(comboBox7.SelectedItem);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Train_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Start_time, x.Admin_id, x.Departure_time, x.Admin.Bus_services, x.Availability, x.Sit_Availability };
                    MessageBox.Show("update sucessfully");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Admindltbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox3.Text == "Bus_service")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Bus_services.Where(w => w.Id == pid).FirstOrDefault();
                    dbs.Bus_services.DeleteOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Bus_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Strat_Time, x.Admin_id, x.Depurture_time, x.Admin.Bus_services, x.Availability, x.Available_sit };
                    MessageBox.Show("delete sucessfully");
                }
                else if (comboBox3.Text == "Air")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Airs.Where(w => w.Id == pid).FirstOrDefault();
                    dbs.Airs.DeleteOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Airs
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Start_time, x.Admin_id, x.Departure_Time, x.Admin.Bus_services, x.Availability, x.Sit_Availability };
                    MessageBox.Show("delete sucessfully");
                }
                else if (comboBox3.Text == "Train_service")
                {
                    int pid = Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value.ToString());
                    var query = dbs.Train_services.Where(w => w.Id == pid).FirstOrDefault();
                    dbs.Train_services.DeleteOnSubmit(query);
                    dbs.SubmitChanges();
                    dataGridView3.DataSource = from x in dbs.Train_services
                                               where x.Admin_id == Convert.ToInt32(textBox7.Text)
                                               select new { x.Id, x.Name, x.Rent, x.Start_place, x.Departure_place, x.Start_time, x.Admin_id, x.Departure_time, x.Admin.Bus_services, x.Availability, x.Sit_Availability };
                    MessageBox.Show("delete sucessfully");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Admininsertbtn_Click(object sender, EventArgs e)
        {
            try {
                Admin query = new Admin();
                query.Name = textBox9.Text;
                query.Password = textBox10.Text;
                query.CompanyName = textBox11.Text;
                query.Address = textBox12.Text;
                if (radioButton6.Checked)
                {
                    query.ServiceName = "Bus_service";
                }
                else if (radioButton6.Checked)
                {
                    query.ServiceName = "Air";
                }
                else if (radioButton7.Checked)
                {
                    query.ServiceName = "Train_service";
                }


                dbs.Admins.InsertOnSubmit(query);
                dbs.SubmitChanges();
                MessageBox.Show("Insert sucessful");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

    }
}
